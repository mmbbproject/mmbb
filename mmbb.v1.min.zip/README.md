# Minimalist Modern Bootstrap Blogger
#### Author [@ox69xo](http://twitter.com/ox69xo "Follow me on Twitter")
Template Blogger di buat menggunakan [Bootstrap](https://getbootstrap.com "Get Bootstrap") v.3.3.7, sangat sederhana dan hanya menggunakan element *Panel* untuk widget dan post detail, *Pager*, *List Group* untuk home page (post), *Breadcrumb*, *Navbar* dan pastinya *Grid System*. 
#### Pemasangan:
- Download file [mmbb.v1.min.zip](https://github.com/mmbbproject/mmbb/blob/master/MMBB-v1.min.zip "Download MMBB Template v1"), extract ke Desktop / folder manapun.
- Login ke akun Blogger
- Pilih blog yang mau di ganti templatenya
- Buka menu *Theme*
- **Backup!** template, tombol ada di sebelah kanan atas **Backup / Restore**, pilih download themes, close.
- Edit template, masih di menu *Theme*, di samping kanannya ada 2 jenis template **Live on Blog** (desktop) dan **Mobile**
- Pilih tombol *Setting* di bagian bawah **Mobile**, aktifkan **No. Show desktop theme on mobile devices**, save.
- Pilih tombol *Edit HTML* di bagian bawah **Live on Blog**
- Kembali ke file hasil extract tadi, buka file .xml, select all `CTRL + A` dan copy.
- Kembali ke Browser, paste di halaman *Edit HTML*.
- Save.

[Lihat selengkapnya di Google](https://www.google.co.id/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=cara+mengganti+template+blogger&* "Pemasangan template Blogger") # [Demo](http://ip3web.blogspot.com "Demo MMBB Template blogger") # [Tips & trick](http://jqueryholic.blogspot.com "Personal Blog") # [Website](http://mmbbproject.github.io "Webpage MMBB Template")
___
This free Blogger template is licensed under the Creative Commons Attribution 4.0 License, which permits both personal and commercial use.